"""
IDLE main entry point

Run IDLE as python -m idlelib
"""


import idlelib.PyShell
idlelib.PyShell.main()
